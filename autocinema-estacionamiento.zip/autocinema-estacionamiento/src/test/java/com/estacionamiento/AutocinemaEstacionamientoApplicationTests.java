package com.estacionamiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocinemaEstacionamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
