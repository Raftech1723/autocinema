package com.estacionamiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutocinemaEstacionamientoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutocinemaEstacionamientoApplication.class, args);
	}

}
