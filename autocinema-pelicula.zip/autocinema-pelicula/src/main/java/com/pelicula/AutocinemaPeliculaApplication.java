package com.pelicula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutocinemaPeliculaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutocinemaPeliculaApplication.class, args);
	}

}
