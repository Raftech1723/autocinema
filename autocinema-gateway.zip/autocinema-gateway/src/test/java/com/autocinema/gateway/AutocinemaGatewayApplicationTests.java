package com.autocinema.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocinemaGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
