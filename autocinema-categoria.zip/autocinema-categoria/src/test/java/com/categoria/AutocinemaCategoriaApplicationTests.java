package com.categoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocinemaCategoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
