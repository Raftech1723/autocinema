package com.usuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutocinemaUsuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutocinemaUsuarioApplication.class, args);
	}

}
