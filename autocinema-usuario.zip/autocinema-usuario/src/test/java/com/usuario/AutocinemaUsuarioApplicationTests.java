package com.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocinemaUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
