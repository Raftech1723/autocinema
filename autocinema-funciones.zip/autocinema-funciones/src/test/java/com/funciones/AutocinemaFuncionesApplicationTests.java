package com.funciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocinemaFuncionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
