package com.sala;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocinemaSalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
