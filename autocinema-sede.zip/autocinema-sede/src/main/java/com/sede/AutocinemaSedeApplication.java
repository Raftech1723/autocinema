package com.sede;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutocinemaSedeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutocinemaSedeApplication.class, args);
	}

}
