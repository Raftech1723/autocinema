package com.sede;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocinemaSedeApplicationTests {

	@Test
	void contextLoads() {
	}

}
