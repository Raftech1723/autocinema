package com.metodopago;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutocinemaMetodopagoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutocinemaMetodopagoApplication.class, args);
	}

}
