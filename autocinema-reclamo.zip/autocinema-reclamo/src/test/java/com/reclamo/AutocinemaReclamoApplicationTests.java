package com.reclamo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocinemaReclamoApplicationTests {

	@Test
	void contextLoads() {
	}

}
