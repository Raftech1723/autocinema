package com.reclamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutocinemaReclamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutocinemaReclamoApplication.class, args);
	}

}
